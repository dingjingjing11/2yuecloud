import Vue from 'vue';
var vue = new Vue();
export default vue;