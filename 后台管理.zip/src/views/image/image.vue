<template>
   <div>
     资产管理
   </div>
</template>
<script>
export default {
   name: '',
   components: {
     
   },
   
   data() {
     return {
       
     }
   },
   computed: {
     
   },
   watch: {
     
   },
   mounted() {
     
   },
   methods: {
     
   }
};
</script>
<style lang='' scoped>
</style>