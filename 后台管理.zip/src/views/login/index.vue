
<template>
   <div class="wrap">
      <div>UNI-ADMIN</div>
      <div>
         <el-form :model="ruleForm" status-icon :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
            <el-form-item label="" prop="username">
               <el-input type="text" v-model="ruleForm.username" autocomplete="off" placeholder="请输入账号"></el-input>
            </el-form-item>
            <el-form-item label="" prop="password">
               <el-input type="password" v-model="ruleForm.password" autocomplete="off" placeholder="请输入密码"></el-input>
            </el-form-item>
         </el-form>
      </div>
      <div class="login" @click="submit">立即登录</div>
   </div>
</template>
<script>
import axios from 'axios'
export default {
   name: '',
   components: {

   },

   data() {
      return {
         ruleForm:{
          username: '',
         password: ''
           },
           rules:{
            username:[{required:true,message:'请输入用户名',trigger:'blur'}],
            password:[{required:true,message:'请输入密码',trigger:'blur'}]
           }        
      }
   },
   computed: {

   },

   mounted() {
      axios.post('http://ceshi5.dishait.cn/admin/login',{username:'admin',password:'admin'}).then((res)=>{
           if(res.data.msg=='ok'){
             console.log(res.data);
             localStorage.token=res.data.data.token;
             localStorage.tree=JSON.stringify(res.data.data.tree) ;
             this.$router.push('/index')

           }
      })
   
   },
   methods: {
      submit(){
         // this.$router.push({name:'index'})
      //   this.$refs.ruleForm.validate((e) => {
      //     console.log(e);
      //     if (!e) return;
         
      //     this.$router.push({name:'index'})
      // })

        }  
           }  
}
</script>
<style lang='scss' scoped>
.wrap {
   width: 500px;
   height: 300px;
   border: 1px solid #ccc;
   margin: 100px auto;
}

.wrap div:nth-of-type(1) {
   font-size: 30px;
   font-weight: 800;
   border-bottom: 1px solid #ccc;
   text-align: center;
   margin: 0 auto;
}

// .wrap div:nth-of-type(2) {
//    width: 400px;
//    height: 50px;
//    border: 1px solid #ccc;
//    margin: 30px auto;
//    line-height: 50px;
//    // padding-left: 20px;
// }

// .wrap div:nth-of-type(3) {
//    width: 400px;
//    height: 50px;
//    border: 1px solid #ccc;
//    margin: 30px auto;
//    line-height: 50px;
//    // padding-left: 20px;
// }

.login {
   margin-top: 150px;
   width: 400px;
   height: 50px;
   border: 1px solid #ccc;
   margin: 30px auto;
   background-color: #2d8585;
   text-align: center;
   line-height: 50px;
   border-radius: 15px;
}


input {
   width: 400px;
   height: 49px;
   padding-left: 20px;
   color: #ccc;
}
</style>