<template>
<div>
    <!-- 头部 -->
    <header>
      <div class="un fl">
        UNI-ADMIN
      </div>
      <div class="header-nav  fr">
        <ul class="fl">
          <li  v-if="tree[tabIndex].child"  v-for="(item,index) in tree" :key="item.id" @click="changeTab(index,item.desc)">{{item.name}}</li>
          <!-- <router-link  tag="li" :to="" v-for></router-link> -->
          <!-- <li>首页</li>
          <li>商品</li>
          <li>订单</li>
          <li>会员</li>
          <li>设置</li>
          <li>测试</li> -->
        </ul>
        <span class="fr ">
          <el-avatar icon="el-icon-user-solid info"></el-avatar>
          admin
        </span>
      </div>
    </header>
    <!-- 中间内容 -->
    <div class="container">
      <div class="left fl">
        <ul>
        <li v-for="item in tree[tabIndex].child" @click="changeBar(item.desc)" >{{item.name}}</li>
        </ul>
        <!-- <el-row class="tac">
        <el-col :span="12">
          <el-menu default-active="2" class="el-menu-vertical-demo" @open="handleOpen" @close="handleClose"
            background-color="#545c64" text-color="#fff" active-text-color="#ffd04b">
            <el-submenu index="1">
              <template slot="title">
                <i class="el-icon-s-home"></i>
                <span>后台首页</span>
              </template>       
                         
            </el-submenu>
            <el-menu-item index="2">
              <i class="el-icon-picture"></i>
              <span slot="title">相册管理</span>
            </el-menu-item>
             <el-menu-item index="3" disabled>
              <i class="el-icon-s-claim"></i>
              <span slot="title">商品列表</span>
            </el-menu-item> -->
            <!-- <el-menu-item index="4">
              <i class="el-icon-s-claim"></i>
              <span slot="title">商品列表</span>
            </el-menu-item>
          </el-menu>
        </el-col>
        </el-row> --> 
      </div>
      <!-- 中间部分 -->
      <div class="center fl">
        <div>
        <div class="wrap fl">
        <div class="ge">
          <i class="el-icon-user-solid"></i>         
        </div>
        <div class="jiage">
         <p>30</p>
          <p>关注人数（个）</p>
          </div>
        </div>
        <div class="wrap fr">
        <div class="bi">
          <i class="el-icon-s-finance"></i>   
        </div>
        <div class="jiage">
        <p>120</p>
        <p>订单总数（笔）</p>
        </div>
        </div>
        </div>
        <div class="shangpin">
          <div class="dianpu">
            <span class="fl">店铺及商品提示</span>
            <span class="fr">需要关注的店铺信息及待处理事项</span>
            </div>
          <div class="shu">
            <div class="zi"><span>64</span><span>出售中</span></div>
            <div class="zi"><span>10</span><span>待回复</span></div>
            <div class="zi"><span>0</span><span>库存预警</span></div>
            <div class="zi"><span>3</span><span>仓库中</span></div>
          </div>
        </div>
        <div class="shangpin">
          <div class="dianpu">
            <span class="fl">交易提示</span>
            <span class="fr">需要立即处理的交易订单</span>
            </div>
          <div class="huo">
            <div class="dai"><span>0</span><span>待付款</span></div>
            <div class="dai"><span>10</span><span>待发货</span></div>
            <div class="dai"><span>0</span><span>已发货</span></div>
            <div class="dai"><span>3</span><span>已收货</span></div>
            <div class="dai"><span>3</span><span>退款中</span></div>
            <div class="dai"><span>3</span><span>待售后</span></div>         
            
          </div>
          
        </div>
        
      </div>
      <!-- 右边 -->
      <div class="right fl">
        <div class="wrap fl">
        <div class="yuan">
        <i class="el-icon-s-order"> </i>
        </div>
        <div class="jiage">
        <p>4183.80</p>
        <p>今日订单总金额（元）</p>
        </div>
        </div>
        <div class="wrap fr">
        <div class="bai">
        <i class="el-icon-s-data"></i>
        </div>
        <div class="jiage">
        <p>100</p>
        <p>本月销量（笔）</p>
        </div>
        </div>
      </div>
    </div>
  </div>

<!-- layout容器 -->
<index></index>
<!-- <login></login> -->
<!-- <header1></header1>
<nav1></nav1>
<nav2></nav2> -->

<!-- <router-view :key="key"></router-view>  -->

     
<!-- <footer1></footer1> -->
<router-view></router-view>
  
</template>
<script>
// import index from '../views/index/index.vue'
// import login from '../views/login/index.vue'
// import header1 from '../assets/header.vue'
// import nav1 from '../assets/nav.vue'
// import nav2 from '../assets/nav2.vue'
// import footer1 from '../assets/footer.vue'
export default {
    components:{
      // index,
      // login,
      // header1,
    //   nav1,
    //   nav2,
      // footer1
    },
   data() {
      return {
         tree:[],
      tabIndex:0
      }
   },
   created(){
   },
   computed:{
    key(){
        return this.$router.id
    }
   },
   methods:{
     // 顶部导航跳转
   changeTab(index,desc){
    console.log(desc.replaceAll('_','/'));
    this.tabIndex=index;
    this.$router.push({name:desc.replaceAll('_','/')})
   },
   //侧边导航跳转
   changeBar(desc){
    console.log(desc.replaceAll('_','/'));
    this.$router.push({name:desc.replaceAll('_','/')})
   }

   },
   // 存储
  created() {
    if(localStorage.tree){
      this.tree=JSON.parse(localStorage.tree)
      console.log(this.tree);
    }
    //  this.username =JSON.parse(localStorage.userinfo).account
  }
}
</script>
<style >
 .bigbox{
    width: 100%;
 }
</style>
