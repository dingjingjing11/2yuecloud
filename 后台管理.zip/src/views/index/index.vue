<template>
  <div>
    <!-- 头部 -->
    <header>
      <div class="un fl">
        UNI-ADMIN
      </div>
      <div class="header-nav  fr">
        <ul class="fl">
          <li  v-if="tree[tabIndex].child"  v-for="(item,index) in tree" :key="item.id" @click="changeTab(index,item.desc)">{{item.name}}</li>
          <!-- <router-link  tag="li" :to="" v-for></router-link> -->
          <!-- <li>首页</li>
          <li>商品</li>
          <li>订单</li>
          <li>会员</li>
          <li>设置</li>
          <li>测试</li> -->
        </ul>
        <span class="fr ">
          <el-avatar icon="el-icon-user-solid info"></el-avatar>
          admin
        </span>
      </div>
    </header>
    <!-- 中间内容 -->
    <div class="container">
      <div class="left fl">
        <ul>
        <li v-for="item in tree[tabIndex].child" @click="changeBar(item.desc)" >{{item.name}}</li>
        </ul>
        <!-- <el-row class="tac">
        <el-col :span="12">
          <el-menu default-active="2" class="el-menu-vertical-demo" @open="handleOpen" @close="handleClose"
            background-color="#545c64" text-color="#fff" active-text-color="#ffd04b">
            <el-submenu index="1">
              <template slot="title">
                <i class="el-icon-s-home"></i>
                <span>后台首页</span>
              </template>       
                         
            </el-submenu>
            <el-menu-item index="2">
              <i class="el-icon-picture"></i>
              <span slot="title">相册管理</span>
            </el-menu-item>
             <el-menu-item index="3" disabled>
              <i class="el-icon-s-claim"></i>
              <span slot="title">商品列表</span>
            </el-menu-item> -->
            <!-- <el-menu-item index="4">
              <i class="el-icon-s-claim"></i>
              <span slot="title">商品列表</span>
            </el-menu-item>
          </el-menu>
        </el-col>
        </el-row> --> 
      </div>
      <!-- 中间部分 -->
      <div class="center fl">
        <div>
        <div class="wrap fl">
        <div class="ge">
          <i class="el-icon-user-solid"></i>         
        </div>
        <div class="jiage">
         <p>30</p>
          <p>关注人数（个）</p>
          </div>
        </div>
        <div class="wrap fr">
        <div class="bi">
          <i class="el-icon-s-finance"></i>   
        </div>
        <div class="jiage">
        <p>120</p>
        <p>订单总数（笔）</p>
        </div>
        </div>
        </div>
        <div class="shangpin">
          <div class="dianpu">
            <span class="fl">店铺及商品提示</span>
            <span class="fr">需要关注的店铺信息及待处理事项</span>
            </div>
          <div class="shu">
            <div class="zi"><span>64</span><span>出售中</span></div>
            <div class="zi"><span>10</span><span>待回复</span></div>
            <div class="zi"><span>0</span><span>库存预警</span></div>
            <div class="zi"><span>3</span><span>仓库中</span></div>
          </div>
        </div>
        <div class="shangpin">
          <div class="dianpu">
            <span class="fl">交易提示</span>
            <span class="fr">需要立即处理的交易订单</span>
            </div>
          <div class="huo">
            <div class="dai"><span>0</span><span>待付款</span></div>
            <div class="dai"><span>10</span><span>待发货</span></div>
            <div class="dai"><span>0</span><span>已发货</span></div>
            <div class="dai"><span>3</span><span>已收货</span></div>
            <div class="dai"><span>3</span><span>退款中</span></div>
            <div class="dai"><span>3</span><span>待售后</span></div>         
            
          </div>
          
        </div>
        
      </div>
      <!-- 右边 -->
      <div class="right fl">
        <div class="wrap fl">
        <div class="yuan">
        <i class="el-icon-s-order"> </i>
        </div>
        <div class="jiage">
        <p>4183.80</p>
        <p>今日订单总金额（元）</p>
        </div>
        </div>
        <div class="wrap fr">
        <div class="bai">
        <i class="el-icon-s-data"></i>
        </div>
        <div class="jiage">
        <p>100</p>
        <p>本月销量（笔）</p>
        </div>
        </div>
      </div>
    </div>
  </div>

</template>
<script>
export default {
  data() {
    return {
      tree:[],
      tabIndex:0
    }
  }, 
  methods: {
    // 顶部导航跳转
   changeTab(index,desc){
    console.log(desc.replaceAll('_','/'));
    this.tabIndex=index;
    this.$router.push({name:desc.replaceAll('_','/')})
   },
   //侧边导航跳转
   changeBar(desc){
    console.log(desc.replaceAll('_','/'));
    this.$router.push({name:desc.replaceAll('_','/')})
   }
  },
  // 存储
  created() {
    if(localStorage.tree){
      this.tree=JSON.parse(localStorage.tree)
      console.log(this.tree);
    }
    //  this.username =JSON.parse(localStorage.userinfo).account
  }
}
</script>
<style  scoped>
header {
  width: 100%;
  height: 60px;
  line-height: 60px;
  text-align: center;
  background-color: #545c64;
  color: #fff;
}

.un {
  font-size: 18px;
  margin-left: 10px;
}

.header-nav li {
  float: left;
  margin-right: 30px;
  font-size: 15px;
}

.el-icon-user-solid {
  margin-top: 10px;
 
}

.info {
  margin-top: 10px;
}

.left {
  width: 15%;
  margin-top: 10px;
  background-color: #fff;
}
/* .tac{
  color: #fff;
} */
.center{
  width: 40%;
  height: 500px;
  border: 1px solid #000;
  margin: 14px;
  background-color: #fff;
}
.right{
  width: 40%;
  height: 500px;
  border: 1px solid #000;
  margin: 10px;
  background-color: #fff;
}
.container{
  background-color: hsl(206, 3%, 57%);
}
.wrap{
  width: 48%;
  height: 100px;
  border: 1px solid #ccc;
  background-color: #fff;
  display: flex;
  padding: 20px 0 0 20px;
  font-size: 15px;
}
.ge{
  padding-left: 10px;
  margin-bottom: 10px;
  width: 33px;
  height: 33px;
  /* border: 1px solid #000; */
  background-color:#157ffb;
}
.bi{
  padding-left: 10px;
  width: 33px;
  height: 33px;
  /* border: 1px solid #000; */
  background-color:#30a64a;
}
.yuan{
  padding-left: 10px;
  width: 33px;
  height: 33px;
  /* border: 1px solid #000; */
  background-color:#da3849;
}
.bai{
  padding-left: 10px;
  width: 33px;
  height: 33px;
  /* border: 1px solid #000; */
  background-color:#fec02f;
}
i{
  text-align: center;
  line-height: 33px;
  vertical-align: middle;
}
.jiage{
  margin-left: 10px;
}
.dianpu {
  border: 1px solid #ccc;
  font-size: 15px;
  font-weight: 800;
  height: 40px;
  line-height: 40px;
  padding: 0 20px;
}
.zi span:nth-of-type(1){
  font-size: 30px;
  font-weight: 800;
}
.dianpu span:nth-of-type(2){
  color: hsl(174, 31%, 61%);
}
.shangpin{
  width: 100%;
  height: 100px;
 margin-top: 120px;
}
.shu{
  
  width: 100%;
  display: flex;
  justify-content: space-between;
  padding: 20px 20px;
  border: 1px solid #ccc;
}
.zi{
  width: 20%;
 display: flex;
 flex-direction: column;
 justify-content: space-around;
 background-color:rgb(204, 204, 204);
 text-align: center;
}
.dai{
  width: 12%;
  height: 80px;
   display: flex;
 flex-direction: column;
 justify-content: space-around;
 background-color: rgb(204, 204, 204);
 text-align: center;
}
.dai span:nth-of-type(1){
  font-size: 30px;
  font-weight: 800;
}
.huo{
  
  width: 100%;
  display: flex;
  justify-content: space-between;
  padding: 20px 20px;
  border: 1px solid #ccc;
}


</style>
