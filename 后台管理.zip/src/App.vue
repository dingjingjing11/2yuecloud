<template>
<div>
 <router-view></router-view>
</div>

 <!-- layout 容器 -->
</template>


