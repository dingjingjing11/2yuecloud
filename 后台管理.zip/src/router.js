import Vue from "vue"
import Router from "vue-router"

// import routes from "./common/config/router.js" // 路由配置选项  [{path:xx,components},{}]

const originalPush = Router.prototype.push
Router.prototype.push = function push(location) {
   return originalPush.call(this, location).catch(err => err)
}

Vue.use(Router);

let router = new Router({ 
    routes:[
        {path:'/',component:()=>import('@/views/layout.vue'),
         redirect:'/index',
         children:[
            //后台首页
            {path:'/index',name:'index',component:()=>import('@/views/index/index.vue')},
            // 相册管理
            {path:'/image',name:'image',component:()=>import('@/views/image/index.vue')},
            //商品列表
            {path:'/shop/goods/list',name:'shop/goods/list', component:()=>import('./views/shop/goods/list.vue')},
            // 分类列表
            {path:'/shop/category/list',name:'/shop/category/list',component:()=>import('@/views/shop/category/index.vue')},
            // 商品规格
            {path:'/shop/sku/list',name:'/shop/sku/list',component:()=>import('@/views/shop/sku/list.vue')},
            // 商品类型
            {path:'/shop/type/list',name:'/shop/type/list',component:()=>import('@/views/shop/type/list.vue')},
             // 商品评价
             {path:'/shop/comment/list',name:'/shop/comment/list',component:()=>import('@/views/shop/comment/list.vue')},
            // 订单列表
            {path:'/order/order/list',name:'/order/order/list',component:()=>import('@/views/order/order/index.vue')},
             // 发票管理
             {path:'/order/invoice/list',name:'/order/invoice/list',component:()=>import('@/views/order/invoice/list.vue')},
              // 售后服务
              {path:'/order/after-sale/list',name:'/order/after-sale/list',component:()=>import('@/views/order/after-sale/list.vue')},
            //会员列表
            {path:'/user/user-list/list',name:'/user/user-list/list',component:()=>import('@/views/user/user-list/list.vue')},
             //会员等级
             {path:'/user/user-level/list',name:'/user/user-level/list',component:()=>import('@/views/user/user-level/list.vue')},
            //基础设置
            {path:'/set/base',name:'/set/base',component:()=>import('@/views/set/base.vue')},
             //物流设置
             {path:'/set/express',name:'/set/express',component:()=>import('@/views/set/express.vue')},
              //管理员管理设置
            {path:'/set/manager',name:'/set/manager',component:()=>import('@/views/set/manager.vue')},
             //交易设置
             {path:'/set/payment',name:'/set/payment',component:()=>import('@/views/set/payment.vue')},
            // 资产管理
            {path:'/image',name:'image',component:()=>import('@/views/image/image.vue')},


         ]

    },
        
      //   {path:'/login',name:'login', component:()=>import('@/views/login/index.vue')}
    ]
 })

// 全局前置守卫
// router.beforeEach((to, from, next) => {
// 	// 获取token
// 	let token = window.sessionStorage.getItem('token')
// 	let user = window.sessionStorage.getItem('user')
// 	if(token){ // 已登录
// 		// 防止重复登录
// 		if(to.path === '/login'){
// 			Vue.prototype.$message.error('请不要重复登录');
// 			return next({name:from.name ? from.name : 'index'})
// 		}
// 		// 其他验证...
// 		if(to.name !== 'error_404'){
// 			// 超级管理员跳过验证
// 			if(user){
// 				user = JSON.parse(user)
// 				if(user.super === 1){
// 					return next()
// 				}
// 			}
// 			// 验证
// 			let rules = window.sessionStorage.getItem('rules')
// 			rules = rules ? JSON.parse(rules) : []
			
// 			let index = rules.findIndex(item=>{
// 				return item.rule_id > 0 && item.desc === to.name
// 			})
// 			if(index === -1){
// 				Vue.prototype.$message.error('你没有权限')
// 				return next({name:from.name ? from.name : 'error_404'})
// 			}
// 		}
// 		next();
// 	} else {
// 		// 跳过登录页验证
// 		if(to.path === '/login'){
// 			return next();
// 		}
// 		// 未登录
// 		Vue.prototype.$message.error('请先登录');
// 		next({ path:'/login' })
// 	}
// })

export default router